package com.tonyseo.ex85firebasechatting;

public class G {
    public static String nickName;
    public static String profileUrl;

}
