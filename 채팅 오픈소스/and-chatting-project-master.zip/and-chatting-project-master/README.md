## Team Project

## Subject
The purpose of chatting between users through Android app

## Feature
* Intro Page
* Login Page
* Main Page
* Chatting Page
* ...

## Issues
* **Refactoring required**
  * Structural change
  * Objectification
* **Socket Study**
  * https://github.com/jinusong/Android-Socket
  
## Result
* What are the advantages of sockets?
* What did you learn?
