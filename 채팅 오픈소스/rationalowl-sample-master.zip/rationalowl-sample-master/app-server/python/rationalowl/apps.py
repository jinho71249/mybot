from django.apps import AppConfig


class RationalowlConfig(AppConfig):
    name = 'rationalowl'
