package test;

public class Main {
    
    
    public static void main(String[] args) {
        new SampleServerView().setVisible(true);        
    }   
}