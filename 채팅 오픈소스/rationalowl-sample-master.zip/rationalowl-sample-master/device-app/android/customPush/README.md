래셔널아울 커스텀 푸시 샘플앱은 래셔널아울 실시간 API와 이와함께 제공되는 기본 푸시의 사용법을 알려주는 기본 샘플앱에다 래셔널아울 커스텀푸시의 기능을 추가한 샘플앱이다. 

[기본 샘플앱 설명](https://github.com/RationalOwl/rationalowl-sample/tree/master/device-app/android/sample1)

[커스텀푸시 앱 개발](https://rationalowl.tistory.com/21) 문서의 '안드로이드 단말앱 개발' 파트 참고
