# 래셔널아울 Android 단말앱 샘플
Android 단말앱 샘플은 Android 단말앱 라이브러리에서 제공하는 API를 이용해서 단말앱을 만드는 것을 쉽게 따라할 수 있도록 쉽게 작성되었다.

##  [샘플앱1](https://github.com/RationalOwl/rationalowl-sample/tree/master/device-app/android/sample1)

채팅, 실시간 소셜앱, 게임 등 실시간 데이터 전달과 이와 함께 제공되는 푸시 알림에 대한 샘플앱이다.


##  [커스텀 푸시앱](https://github.com/RationalOwl/rationalowl-sample/tree/master/device-app/android/customPush)

래셔널아울 커스텀푸시는 안드로이드에서 지원하는 이미지 푸시, 팝업 푸시, 멀티미디어 푸시알림 등 사용자 맞춤형 푸시 알림을 지원하고
그에 더해 다음의 푸시알림 전달 여부에 대한 고속 트래킹을 지원한다.
