//
//  NotificationService.h
//  NotiServiceExtension
//
//  Created by 김정도 on 28/02/2019.
//  Copyright © 2019 Rationalowl. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
