//
//  AppDelegate.h
//  sample
//
//  Created by 김정도 on 2018. 1. 23..
//  Copyright © 2018년 Rationalowl. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate, UNUserNotificationCenterDelegate> 

@property (strong, nonatomic) UIWindow *window;


@end

