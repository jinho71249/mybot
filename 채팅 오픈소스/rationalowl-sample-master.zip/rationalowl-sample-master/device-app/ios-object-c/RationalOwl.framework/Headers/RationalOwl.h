//
//  RationalOwl.h
//  RationalOwl
//
//  Created by 김정도 on 2016. 6. 28..
//  Copyright © 2016년 RationalOwl. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RationalOwl.
FOUNDATION_EXPORT double RationalOwlVersionNumber;

//! Project version string for RationalOwl.
FOUNDATION_EXPORT const unsigned char RationalOwlVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RationalOwl/PublicHeader.h>
#import <RationalOwl/MinervaManager.h>
#import <RationalOwl/MinervaDelegate.h>
#import <RationalOwl/Result.h>

