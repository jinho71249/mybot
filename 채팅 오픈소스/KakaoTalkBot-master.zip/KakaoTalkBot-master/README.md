# KakaoTalk Bot

만동이님이 만드신 카카오톡 봇에서 <s>합법적으로</s> 소스 냠냠해서 만든 앱입니다.

https://github.com/BackupDead/ScriptableKakaoBot
